<?php
    include 'views/napbar.php';
?>
<?php
echo "This is body blogs";
?>
<?php
    include 'views/footer.php';
?>
