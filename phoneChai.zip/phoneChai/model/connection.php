<?php
$dbhost="localhost";
$dbuser="root";
$dbpass="";
//$conn=mysql_connect();
// $db = new mysqli();
$db = mysqli_connect($dbhost,$dbuser,$dbpass, "phonechai");
if(!$db){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 

?> 
