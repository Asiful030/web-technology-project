
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
  
    <link rel="stylesheet" href="template/style.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://unpkg.com/tailwindcss@1.7.0/dist/tailwind.min.css" rel="stylesheet">


    <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">



<style>
@import url('https://fonts.googleapis.com/css2?family=Lobster&family=Pattaya&family=Poppins:wght@200;400;600&family=Roboto&display=swap');
body {
  margin: 0;
  font-family: 'Poppins', sans-serif;
    background-color: #F8F8FF;
}

.topnav {
  overflow: hidden;
  background-color: #F8F8FF;
	padding-top:20px
  
}

.topnav a {
    text-decoration: none;
    color: #009933;
    font-size: 1.2rem;
    font-weight: bold;

  float: left;
  display: block;
	padding: 15px 20px;
  text-align: center;


  margin: 10px;
}

.topnav a:hover:not(:first-child) {
    border-bottom: 3px solid #ff6666;
    border-radius: 7px;
    transition: all 0.2s ease;
}



.topnav .icon {
  display: none;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
    
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
    padding-top: 20px;
  }
}
  .hamburger {
    padding-right: 20px;
    cursor: pointer;
  }

  .hamburger .line {
    display: block;
    width: 40px;
    height: 5px;
    margin-bottom: 10px;
    background-color: black;
  }
  .topnav a.logo {
    font-size: 32px;
	color:#009933;
    padding-left: 20px;
  }

</style>
</head>
<body>

<div class="topnav" id="myTopnav">
  <a href="#home" class="logo">Ph<span style="color: #ff3333;">one</span>Chai</a>

  <a href="/phoneChai/index.php">Home</a>
  <a href="/phoneChai/phones.php?brand=">Phones</a>
  <a href="/phoneChai/my_order.php">My Order</a>
  <a href="/phoneChai/admin.php">Admin</a>
  <a href="/phoneChai/logout.php">Logout</a>

  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
                 <div class="hamburger">
                <span class="line"></span>
                <span class="line"></span>
                <span class="line"></span>
              </div>
  </a>
  </div>




<script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>

</body>
</html>

